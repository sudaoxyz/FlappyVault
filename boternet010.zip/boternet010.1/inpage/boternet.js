window.hasBoternet = true;
